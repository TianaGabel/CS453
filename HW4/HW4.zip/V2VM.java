import cs132.util.ProblemException;
import cs132.vapor.parser.VaporParser;
import cs132.vapor.ast.VaporProgram;
import cs132.vapor.ast.*;
import cs132.vapor.ast.VBuiltIn.Op;

import java.io.InputStreamReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.HashMap;

import javax.management.RuntimeErrorException;

public class V2VM {
  public static void main(String[] args) {
    try{
      VaporProgram vp = parseVapor(System.in, System.out);
      
      VMWrapper wrapper = new VMWrapper();
      RuntimeException r = new RuntimeException();

      RegAllocVisitor<VMWrapper,RuntimeException> regalloc =  new RegAllocVisitor();
      ToVaporMVisitor<VMWrapper,RuntimeException> bv =  new ToVaporMVisitor();
      bv.setWrapper(wrapper);

      for(VDataSegment vds: vp.dataSegments){
        System.out.println("const " + vds.ident);
        for (VOperand v: vds.values){
          System.out.println( "   " +v);
        }
        System.out.println("");
      }

      for(VFunction vf : vp.functions){
        HashMap<Integer,String> labelsByLoc = new HashMap<>();
        //Stuff for labels
        for(VCodeLabel l: vf.labels){ 
          if (labelsByLoc.get(l.instrIndex) != null){ //in case 2 labels are at the same location
            String prev = labelsByLoc.get(l.instrIndex);
            labelsByLoc.put(l.instrIndex, (prev + "\n   " + l.ident + ":"));
          } else {
            labelsByLoc.put(l.instrIndex, ("   " + l.ident + ":"));
          }
        }
        

        //stuff for function declaration
        for(VInstr vi: vf.body){
          vi.accept(wrapper, regalloc); //out
        }
        wrapper.incrIn(vf.params.length-4); //in
        wrapper.incrLocal(vf.vars.length);  //min for backup local
        wrapper.addFunction(vf.ident);

        System.out.println(wrapper.getFunctionDeclartion(vf.ident));
        wrapper.resetReallocCounts();

        //Locals mapping
        wrapper.initLocals(vf.vars);

        //Stuff for everything else
        int countForlabels = 0;
        
        if ((vf.params.length > 0) && !vf.params[0].toString().equals("this")){   //missing a this param, so it is mishandled by the visitor
          wrapper.setIsNotMethod();
        }
        bv.addParams(vf.params);
        if (labelsByLoc.get(countForlabels) != null){ //labels if the first thing
            System.out.println(labelsByLoc.get(countForlabels));
        }
        for(VInstr vi: vf.body){
          vi.accept(wrapper, bv);
          countForlabels++;
          if (labelsByLoc.get(countForlabels) != null){ //labels elsewhere
            wrapper.backupToLocals();
            System.out.println(labelsByLoc.get(countForlabels));
          }
          //System.out.println("-");
        }
        //wrapper.printMap();
        wrapper.resetAll();
      }


    } catch(Exception e){
      System.out.println("BOO main failure");
      e.printStackTrace();
    }

  }
  

  public static VaporProgram parseVapor(InputStream in, PrintStream err)
  throws IOException
{
  Op[] ops = {
    Op.Add, Op.Sub, Op.MulS, Op.Eq, Op.Lt, Op.LtS,
    Op.PrintIntS, Op.HeapAllocZ, Op.Error,
  };
  boolean allowLocals = true;
  String[] registers = null;
  boolean allowStack = false;

  VaporProgram program;
  try {
    program = VaporParser.run(new InputStreamReader(in), 1, 1,
                              java.util.Arrays.asList(ops),
                              allowLocals, registers, allowStack);
  }
  catch (Exception ex) {
    System.out.println("BOO wasn't parsed");
    ex.printStackTrace();
    err.println(ex.getMessage());
    return null;
  }

  return program;
}
}